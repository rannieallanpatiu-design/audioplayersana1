import 'package:flutter/cupertino.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/song.dart';
import '../providers/audio_provider.dart';
import '../providers/library_provider.dart';
import '../widgets/song_tile.dart';

class LibraryScreen extends ConsumerWidget {
  const LibraryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final library = ref.watch(libraryProvider);
    final playback = ref.watch(audioControllerProvider);
    final bundled = library.where((s) => s.source == SongSource.asset).toList();
    final imported = library.where((s) => s.source == SongSource.file).toList();

    return ListView(
      padding: const EdgeInsets.only(top: 24, bottom: 160),
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Library',
                style: TextStyle(color: CupertinoColors.white, fontSize: 26, fontWeight: FontWeight.bold),
              ),
              CupertinoButton(
                padding: EdgeInsets.zero,
                minSize: 0,
                onPressed: () async {
                  final count = await ref.read(libraryProvider.notifier).importFromDevice();
                  if (context.mounted && count > 0) {
                    _toast(context, 'Imported $count song${count == 1 ? '' : 's'}');
                  }
                },
                child: const Icon(CupertinoIcons.folder_badge_plus, color: CupertinoColors.white, size: 26),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        _SectionHeader('Bundled (${bundled.length})'),
        ...bundled.asMap().entries.map(
              (e) => SongTile(
            song: e.value,
            index: e.key,
            isActive: playback.currentSong?.id == e.value.id,
            onTap: () => ref.read(audioControllerProvider.notifier).playQueue(bundled, e.key),
          ),
        ),
        const SizedBox(height: 12),
        _SectionHeader('Imported from device (${imported.length})'),
        if (imported.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            child: Text(
              'Tap the folder icon above to add songs from your phone.',
              style: TextStyle(color: CupertinoColors.white.withOpacity(0.5), fontSize: 13),
            ),
          )
        else
          ...imported.asMap().entries.map(
                (e) => Dismissible(
              key: ValueKey(e.value.id),
              direction: DismissDirection.endToStart,
              background: Container(
                alignment: Alignment.centerRight,
                padding: const EdgeInsets.only(right: 28),
                child: const Icon(CupertinoIcons.delete, color: CupertinoColors.destructiveRed),
              ),
              onDismissed: (_) => ref.read(libraryProvider.notifier).removeSong(e.value.id),
              child: SongTile(
                song: e.value,
                index: e.key,
                isActive: playback.currentSong?.id == e.value.id,
                onTap: () => ref.read(audioControllerProvider.notifier).playQueue(imported, e.key),
              ),
            ),
          ),
      ],
    );
  }

  void _toast(BuildContext context, String message) {
    showCupertinoModalPopup(
      context: context,
      builder: (context) => CupertinoActionSheet(
        message: Text(message),
        actions: [
          CupertinoActionSheetAction(onPressed: () => Navigator.pop(context), child: const Text('OK')),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
      child: Text(
        title,
        style: TextStyle(color: CupertinoColors.white.withOpacity(0.7), fontSize: 14, fontWeight: FontWeight.w600),
      ),
    );
  }
}
