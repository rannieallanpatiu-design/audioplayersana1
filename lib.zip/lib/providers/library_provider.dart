import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/song.dart';
import '../services/file_import_service.dart';

const _prefsKey = 'liquid_music_library_v1';

/// Seed tracks bundled under assets/audio/. Replace these with your own
/// files and update pubspec.yaml + this list accordingly.
final List<Song> kBundledSongs = [
  const Song(
    id: 'asset_1',
    title: 'Midnight Drift',
    artist: 'Liquid Glass Demo',
    path: 'assets/audio/sample_1.mp3',
    source: SongSource.asset,
  ),
  const Song(
    id: 'asset_2',
    title: 'Neon Tide',
    artist: 'Liquid Glass Demo',
    path: 'assets/audio/sample_2.mp3',
    source: SongSource.asset,
  ),
];

/// Holds the full music library: bundled assets + anything the user has
/// imported from device storage. Imported songs are persisted locally via
/// SharedPreferences so they survive app restarts.
class LibraryController extends StateNotifier<List<Song>> {
  LibraryController() : super([...kBundledSongs]) {
    _restoreImported();
  }

  final FileImportService _importService = FileImportService();

  Future<void> _restoreImported() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_prefsKey);
    if (raw == null) return;
    final list = (jsonDecode(raw) as List)
        .map((e) => Song.fromJson(e as Map<String, dynamic>))
        .toList();
    state = [...kBundledSongs, ...list];
  }

  Future<void> _persistImported() async {
    final prefs = await SharedPreferences.getInstance();
    final imported = state.where((s) => s.source == SongSource.file).toList();
    await prefs.setString(_prefsKey, jsonEncode(imported.map((s) => s.toJson()).toList()));
  }

  /// Opens the system file/media picker and appends selected tracks.
  Future<int> importFromDevice() async {
    final imported = await _importService.pickAndImportSongs();
    if (imported.isEmpty) return 0;
    state = [...state, ...imported];
    await _persistImported();
    return imported.length;
  }

  Future<void> removeSong(String id) async {
    state = state.where((s) => s.id != id).toList();
    await _persistImported();
  }
}

final libraryProvider = StateNotifierProvider<LibraryController, List<Song>>(
      (ref) => LibraryController(),
);

/// Live-filtered search results driven by [searchQueryProvider].
final searchQueryProvider = StateProvider<String>((ref) => '');

final searchResultsProvider = Provider<List<Song>>((ref) {
  final query = ref.watch(searchQueryProvider).trim().toLowerCase();
  final library = ref.watch(libraryProvider);
  if (query.isEmpty) return library;
  return library
      .where((s) =>
  s.title.toLowerCase().contains(query) || s.artist.toLowerCase().contains(query))
      .toList();
});
