import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/library_provider.dart';
import '../theme/gradients.dart';

enum GlassTab { home, search, library }

/// "Liquid glass" bottom navigation bar: frosted blur + soft gradient tint
/// + a hairline gradient border, similar to iOS 18-style glass surfaces.
///
/// It has 3 destinations — Home / Search / Library — and the middle
/// (search) tab expands in place into a live search field when tapped.
class LiquidGlassTabBar extends ConsumerStatefulWidget {
  final GlassTab current;
  final ValueChanged<GlassTab> onTabSelected;

  /// Exposes the laid-out width so the mini player pill can compute where
  /// "between home and search" actually sits on screen.
  final GlobalKey barKey;

  const LiquidGlassTabBar({
    super.key,
    required this.current,
    required this.onTabSelected,
    required this.barKey,
  });

  @override
  ConsumerState<LiquidGlassTabBar> createState() => _LiquidGlassTabBarState();
}

class _LiquidGlassTabBarState extends ConsumerState<LiquidGlassTabBar> {
  bool _searchExpanded = false;
  final _searchFocus = FocusNode();

  @override
  void dispose() {
    _searchFocus.dispose();
    super.dispose();
  }

  void _onSearchTap() {
    setState(() => _searchExpanded = true);
    widget.onTabSelected(GlassTab.search);
    _searchFocus.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: ClipRRect(
        key: widget.barKey,
        borderRadius: BorderRadius.circular(28),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 260),
            curve: Curves.easeOutCubic,
            height: 64,
            decoration: BoxDecoration(
              gradient: AppGradients.glassTint(),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: CupertinoColors.white.withOpacity(0.22),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: CupertinoColors.black.withOpacity(0.35),
                  blurRadius: 24,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: _searchExpanded
                ? _buildSearchField()
                : Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _TabIcon(
                  icon: CupertinoIcons.house_fill,
                  label: 'Home',
                  selected: widget.current == GlassTab.home,
                  onTap: () =>
                      widget.onTabSelected(GlassTab.home),
                ),
                _TabIcon(
                  icon: CupertinoIcons.search,
                  label: 'Search',
                  selected: widget.current == GlassTab.search,
                  onTap: _onSearchTap,
                ),
                _TabIcon(
                  icon: CupertinoIcons.music_albums_fill,
                  label: 'Library',
                  selected: widget.current == GlassTab.library,
                  onTap: () =>
                      widget.onTabSelected(GlassTab.library),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSearchField() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: [
          const Icon(
            CupertinoIcons.search,
            color: CupertinoColors.white,
            size: 20,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: CupertinoTextField(
              focusNode: _searchFocus,
              placeholder: 'Search songs or artists',
              placeholderStyle: TextStyle(
                color: CupertinoColors.white.withOpacity(0.5),
              ),
              style: const TextStyle(
                color: CupertinoColors.white,
              ),
              decoration: const BoxDecoration(
                color: CupertinoColors.transparent,
              ),
              onChanged: (value) {
                ref.read(searchQueryProvider.notifier).state = value;
              },
            ),
          ),
          CupertinoButton(
            padding: EdgeInsets.zero,
            minSize: 0,
            onPressed: () {
              _searchFocus.unfocus();

              ref.read(searchQueryProvider.notifier).state = '';

              setState(() => _searchExpanded = false);

              widget.onTabSelected(GlassTab.home);
            },
            child: const Icon(
              CupertinoIcons.xmark_circle_fill,
              color: CupertinoColors.white,
              size: 22,
            ),
          ),
        ],
      ),
    );
  }
}

class _TabIcon extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _TabIcon({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = selected
        ? CupertinoColors.white
        : CupertinoColors.white.withOpacity(0.5);

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 200),
        scale: selected ? 1.08 : 1.0,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: color,
              size: 24,
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 10,
              ),
            ),
          ],
        ),
      ),
    );
  }
}