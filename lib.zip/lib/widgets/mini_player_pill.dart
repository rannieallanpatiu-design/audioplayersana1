import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/audio_provider.dart';
import '../providers/scroll_provider.dart';
import '../theme/gradients.dart';
import '../screens/now_playing_screen.dart';

/// The floating "now playing" pill.
///
/// Positioning logic (AnimatedPositioned):
///  - Default: a wide pill that floats directly above the glass tab bar,
///    spanning almost the full width, 16px inset from each edge.
///  - Once [pillDockedProvider] flips true (home scroll offset > 50), it
///    animates into a small circular pill that sits ON TOP of the tab
///    bar, horizontally centered between the Home and Search icons.
///
/// The bar has 3 evenly spaced icons (Home, Search, Library) inside a
/// row that's inset 16px from each screen edge. With MainAxisAlignment
/// .spaceEvenly, icon centers land at barWidth*(1/6), (1/2) and (5/6).
/// The midpoint between Home (1/6) and Search (1/2) is barWidth*(1/3).
class MiniPlayerPill extends ConsumerWidget {
  /// Total height reserved for the tab bar + its bottom padding, used to
  /// know how far above the bottom edge the docked pill should sit.
  final double tabBarHeight;

  const MiniPlayerPill({super.key, required this.tabBarHeight});

  static const double _dockedSize = 46;
  static const double _expandedHeight = 72;
  static const double _sideInset = 16;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final playback = ref.watch(audioControllerProvider);
    final docked = ref.watch(pillDockedProvider);
    final screenWidth = MediaQuery.of(context).size.width;

    if (playback.currentSong == null) return const SizedBox.shrink();

    final barContentWidth = screenWidth - (_sideInset * 2);
    final dockedCenterX = _sideInset + (barContentWidth * (1 / 3));

    final double left = docked ? dockedCenterX - (_dockedSize / 2) : _sideInset;
    final double right =
    docked ? screenWidth - dockedCenterX - (_dockedSize / 2) : _sideInset;
    // Docked pill rests centered within the tab bar height; expanded pill
    // floats just above the tab bar.
    final double bottom = docked ? (tabBarHeight - _dockedSize) / 2 + 16 : tabBarHeight + 8;
    final double height = docked ? _dockedSize : _expandedHeight;

    return AnimatedPositioned(
      duration: const Duration(milliseconds: 380),
      curve: Curves.easeOutCubic,
      left: left,
      right: right,
      bottom: bottom,
      height: height,
      child: GestureDetector(
        onTap: () => Navigator.of(context).push(
          CupertinoPageRoute(builder: (_) => const NowPlayingScreen()),
        ),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 380),
          curve: Curves.easeOutCubic,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(docked ? _dockedSize : 24),
            boxShadow: [
              BoxShadow(
                color: CupertinoColors.black.withOpacity(0.4),
                blurRadius: 20,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              decoration: BoxDecoration(
                gradient: AppGradients.accent,
                borderRadius: BorderRadius.circular(docked ? _dockedSize : 24),
                border: Border.all(color: CupertinoColors.white.withOpacity(0.25)),
              ),
              child: docked ? _DockedContent(playback: playback) : _ExpandedContent(playback: playback, ref: ref),
            ),
          ),
        ),
      ),
    );
  }
}

class _DockedContent extends StatelessWidget {
  final PlaybackState playback;
  const _DockedContent({required this.playback});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Icon(
        playback.isPlaying ? CupertinoIcons.pause_fill : CupertinoIcons.play_fill,
        color: CupertinoColors.white,
        size: 20,
      ),
    );
  }
}

class _ExpandedContent extends StatelessWidget {
  final PlaybackState playback;
  final WidgetRef ref;
  const _ExpandedContent({required this.playback, required this.ref});

  @override
  Widget build(BuildContext context) {
    final song = playback.currentSong!;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(gradient: AppGradients.artworkFor(song.id.hashCode)),
              child: const Icon(CupertinoIcons.music_note, color: CupertinoColors.white),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  song.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: CupertinoColors.white, fontWeight: FontWeight.w600, fontSize: 14),
                ),
                Text(
                  song.artist,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: CupertinoColors.white.withOpacity(0.7), fontSize: 12),
                ),
              ],
            ),
          ),
          CupertinoButton(
            padding: EdgeInsets.zero,
            minSize: 0,
            onPressed: () => ref.read(audioControllerProvider.notifier).togglePlayPause(),
            child: Icon(
              playback.isPlaying ? CupertinoIcons.pause_fill : CupertinoIcons.play_fill,
              color: CupertinoColors.white,
              size: 26,
            ),
          ),
          const SizedBox(width: 8),
          CupertinoButton(
            padding: EdgeInsets.zero,
            minSize: 0,
            onPressed: () => ref.read(audioControllerProvider.notifier).next(),
            child: const Icon(CupertinoIcons.forward_fill, color: CupertinoColors.white, size: 22),
          ),
        ],
      ),
    );
  }
}
